package direct
import "example.com/indirect"
func Message() string { return indirect.Message() }
