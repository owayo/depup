module example.com/direct

go 1.17

require example.com/indirect v1.0.0
