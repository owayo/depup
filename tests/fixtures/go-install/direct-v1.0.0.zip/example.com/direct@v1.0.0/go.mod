module example.com/direct

go 1.17
