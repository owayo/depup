package direct
func Message() string { return "old" }
