package indirect
func Message() string { return "new" }
