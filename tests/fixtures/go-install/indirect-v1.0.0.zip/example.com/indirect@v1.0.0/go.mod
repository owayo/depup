module example.com/indirect

go 1.17
